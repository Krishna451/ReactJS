import React from 'react'

class Order extends React.Component{
    constructor(props){
        super(props);

        this.state={
            id:"",
            name:"",
            desc:""
        }
    }


    odrers={
        id:101,
        name:"Grocery",
        desc:"Grocery Related Products!"
    }

    addEventHandler=()=>{
        this.setState({
            id:this.odrers.id,
            name:this.odrers.name,
            desc:this.odrers.desc
        })
        alert("Order Added Succesfully")

    }

    
    showEventHandler=()=>{
        console.log(this.state)
       return(
            <div>
                <p>Order ID:{this.state.id}  </p>
                <p>Order NAme:{this.state.name}  </p>
                <p>Description:{this.state.desc}  </p>
            </div>
        )

    }

    

    render(){
        return(
            <div>
                <button onClick={this.addEventHandler}>ADD</button>
                <button onClick={this.showEventHandler}>SHOW</button>
            </div>
        )
    }

}
export default Order;