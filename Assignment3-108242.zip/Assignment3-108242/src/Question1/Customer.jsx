import React from 'react';

class Customer extends React.Component{
    constructor(props){
        super(props);

        this.state={
            id:"C101",
            name:'Max',
            age:34
        }
       
    }
    handleClick=()=>{ //if u not using arrow function then u have to bind
        this.setState({id:"C101",name:'Joe',age:36})
    }
    render(){
        
           
        return(
            <div>
                <h1>Customer Details</h1><hr/>
            <p>Customer ID: {this.state.id}</p>
            <p>Customer Name: {this.state.name}</p>
            <p>Customer Age: {this.state.age}</p>

            <button onClick={this.handleClick}>Change State</button>
            </div>
        )
    }
}
export default Customer;