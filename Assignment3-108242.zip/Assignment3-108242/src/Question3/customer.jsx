import React from 'react'
import Order from './order'

class Customer extends React.Component{
    render(){
        return(
            <div>
           
            <h1>Order Details of Neetya</h1>
            <Order></Order>
                 
            </div>
        )
    }

}
export default Customer;