import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import Que3 from './Question3/customer'
import Que1 from './Question1/Customer'
import Que2 from './Question2/customer'


//ReactDOM.render(<Que1 />, document.getElementById('root'));//Q1
//ReactDOM.render(<Que2 />, document.getElementById('root'));//Q2
ReactDOM.render(<Que3 />, document.getElementById('root'));//Q3

