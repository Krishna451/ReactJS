import React from 'react';
import Order from './order'

class Customer extends React.Component{
    constructor(props){
        super(props);
        this.state={
            orderid:"",
            ordername:"",
            desc:""
            
        }
        this.updateState=this.updateState.bind(this);
    }

    updateState(){
        let orders=[{
            oid:"B001",
            oname:"Grocery",
            odesc:"Grocery related Products!"
        },
        {
            oid:"G001",
            oname:"Sports",
            odesc:"Sports related Products!"
        }];
        let rorders=orders[Math.floor(Math.random()*2)]
        this.setState(
            {orderid:rorders.oid,
                ordername:rorders.oname,
             desc:rorders.odesc})
         
       
    }
    
    render(){
        return(
            <div>
                <h1>Random Customer Order Details</h1><hr/>
                <ul>
                    <li> <p>Customer ID: C101</p></li>
                    <li><p>Customer Name: Akash</p></li>
                    <li><p>Customer Age: 35</p></li>
                    <li><p>Customer Address: Noida</p></li>              
             
                    <ul>
            <li><p><Order orderid={this.state.orderid} ordername={this.state.ordername} desc={this.state.desc}></Order></p></li>
        </ul>  
                                
                </ul>
                <button onClick={this.updateState}>Add Random Order</button>
                
            </div>
        )
    }
}
export default Customer;