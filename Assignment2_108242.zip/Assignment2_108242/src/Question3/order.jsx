import React from 'react';

class Order extends React.Component{
    orders=[
        {
            orderid:"G001",
            ordername:"Grocery",
            desc:"Grocery Related Products!"
        },
        {
            orderid:"B001",
            ordername:"Sports",
            desc:"Sports Related Products!"
        }
    ]

    render(){
        return(
            
            this.orders.map(x=>{
                return(
               <div>
                   <p>......................</p>
                <p>Order ID:{x.orderid} </p>
                <p>Order Name:{x.ordername} </p>
                <p>Description:{x.desc} </p>
                
                </div>)
            })
            
        )
    }
   
}
export default Order;