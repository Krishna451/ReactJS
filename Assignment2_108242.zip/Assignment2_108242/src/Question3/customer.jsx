import React from 'react';
import Order from './order'

 class Customer extends React.Component{
     customer={
         id:"C001",
         name:"Ravic"
     }

     render(){
         return(
             <div>
                 <h1>Customer Order Details</h1><hr/>
                 <p>Customer ID: {this.customer.id}</p>
                 <p>Customer Name: {this.customer.name}</p>

                 <Order></Order>


             </div>
         )
     }
 }
 export default Customer;