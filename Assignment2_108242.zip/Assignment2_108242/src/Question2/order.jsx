import React from 'react';

class Order extends React.Component{
    
    render(){
        return(
            <div>
             

                <p>Order Id: {this.props.orderid}</p>
                <p>Order Name: {this.props.ordername}</p>
                <p>Description: {this.props.desc}</p>            </div>
        )
    }
}
export default Order;   