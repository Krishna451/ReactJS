import React from 'react'
import Order from './order'

class Customer extends React.Component{
    

    order={

        id:"G001",
        name:"Grocery",
        desc:"Grocery related products!",
        custid:"C001",
        custname:"Ravic",
        age:35,
        address:"Delhi"
    }

    render(){
        return(
            <div>
                <h1>Customer Order Details</h1><hr/>
                <p1>Customer ID:{this.order.custid}</p1><br/>
                <p1>Customer Name:{this.order.custname}</p1><br/>
                <p1>Customer Age:{this.order.age}</p1><br/>
                <p1>Customer Address:{this.order.address}</p1>
                
                <Order orderid={this.order.id}ordername={this.order.name}desc={this.order.desc}></Order>


            </div>
        )
    }

}
export default Customer;