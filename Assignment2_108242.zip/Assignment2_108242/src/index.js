import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import Que1 from './Question1/Question1'
import Que2 from './Question2/customer'
import Que3 from './Question3/customer'
import Customer1 from './Question4/Customer'
import Customer2 from './Question5/customer'

ReactDOM.render(<Que1 id="C0101" name="Ravic" />, document.getElementById('root')); //Q1
//ReactDOM.render(<Que2 />, document.getElementById('root'));//Q2
//ReactDOM.render(<Que3 />, document.getElementById('root'));//Q3



