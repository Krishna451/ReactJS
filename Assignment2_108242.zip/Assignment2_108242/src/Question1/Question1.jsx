import React from 'react';
import PropType from 'prop-types';

class Customer extends React.Component{

    render(){
        return(
            <div>
                <p>Customer Id: {this.props.id}</p>
                <p>Name: {this.props.name}</p>
                <p>Age: {this.props.age}</p>
                <p>Address: {this.props.address}</p>

            </div>
        )
    }
}

Customer.PropType={
    id:PropType.string,
    name:PropType.string ,
    age:PropType.number,
    address:PropType.string 
}

Customer.defaultProps={
    id:"C101",
    name:'Unknown',
    age:32,
    address:'Noida'
}
export default Customer;